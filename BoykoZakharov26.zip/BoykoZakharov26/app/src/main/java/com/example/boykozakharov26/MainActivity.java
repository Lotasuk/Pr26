package com.example.boykozakharov26;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;


public class MainActivity extends AppCompatActivity {

    private TextView mInfoTextView;
    private NotificationBroadcastReceiver mReceiver;

    private static final int NOTIFICATION_ID = 0;
    private static final String NOTIFICATION_ID_STRING = "0";

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        setTitle("NotificationListenerService Demo");

        mInfoTextView = (TextView) findViewById(R.id.textView);
        mReceiver = new NotificationBroadcastReceiver();

        IntentFilter filter = new IntentFilter();
        filter.addAction("com.example.boykozakharov26.NOTIFICATION_LISTENER_EXAMPLE");
        registerReceiver(mReceiver, filter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mReceiver);
    }

    public void onButtonClicked(View view){
        if(view.getId() == R.id.buttonCreateNotification) {

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                CharSequence name = "Orders Notification";
                String description = "Notifications about my order";
                int importance = NotificationManager.IMPORTANCE_DEFAULT;

                NotificationChannel channel = new NotificationChannel(NOTIFICATION_ID_STRING, name, importance);
                channel.setDescription(description);


                notificationManager.createNotificationChannel(channel);

            }
         /*   NotificationCompat.Builder notifyBuilder
                    = new NotificationCompat.Builder(this, NOTIFICATION_ID_STRING)
                    .setContentTitle("You've been notified!")
                    .setContentText("This is your notification text.")
                    .setSmallIcon(R.drawable.ic_launcher_foreground);
            Notification myNotification = notifyBuilder.build();
            notificationManager.notify(NOTIFICATION_ID, myNotification);*/

            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, NOTIFICATION_ID_STRING);
            builder.setContentTitle("Важное уведомление");
            builder.setContentText("Пора кормить кота!");
            builder.setTicker("Хозяин, проснись!");
            builder.setSmallIcon(R.drawable.ic_launcher_foreground);
            builder.setAutoCancel(true);
            manager.notify((int) System.currentTimeMillis(), builder.build());

        }

        else if(view.getId() == R.id.buttonClearNotification){
            Intent intent = new Intent("com.example.boykozakharov26.NOTIFICATION_LISTENER_EXAMPLE");
            intent.putExtra("command", "clearall");
            sendBroadcast(intent);

        }
        else if(view.getId() == R.id.buttonListNotification){
            Intent intent = new Intent("com.example.boykozakharov26.NOTIFICATION_LISTENER_EXAMPLE");
            intent.putExtra("command", "list");
            sendBroadcast(intent);
        }
    }

    class NotificationBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String temp = intent.getStringExtra("command") + "\n" + mInfoTextView.getText();
            mInfoTextView.setText(temp);
        }
    }
}
